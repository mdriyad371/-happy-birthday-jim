
let firstSlideContainer = 
document.getElementsByClassName("slide--content")[0];

let secondSlideContainer = 
document.getElementsByClassName("slide--content--one")[0];

let secondCanvas = 
document.getElementsByClassName("second--canvas")[0];

secondSlideContainer.setAttribute("style","display:none");
secondCanvas.setAttribute("style","display:none");

let thirdCanvas = 
document.getElementsByClassName("third--canvas")[0];

thirdCanvas.setAttribute("style","display:none");



let containerToggleOne = setTimeout(function(){
	firstSlideContainer.setAttribute("style","display:none");
	secondSlideContainer.setAttribute("style","display:block");
},2500);


let removeFirstSlide = setTimeout(function(){
	document.getElementsByClassName("first--slide")[0].setAttribute("style","display:none;")
	secondCanvas.setAttribute("style","display:block");
},6500);

let removeSecondCanvas = setTimeout(function(){
	secondCanvas.setAttribute("style","display:none");
	thirdCanvas.setAttribute("style","display:block")
},9800)


// Happy Birthday melody using Web Audio. Browsers may require one tap before sound can start.
(function () {
  var button = document.getElementById('birthday-music-toggle');
  if (!button) return;
  var audioContext = null, timer = null, playing = false, noteIndex = 0;
  // Happy Birthday to You melody (C major), repeated continuously.
  var melody = [
    [392, .32], [392, .32], [440, .64], [392, .64], [523.25, .64], [493.88, 1.0],
    [392, .32], [392, .32], [440, .64], [392, .64], [587.33, .64], [523.25, 1.0],
    [392, .32], [392, .32], [783.99, .64], [659.25, .64], [523.25, .64], [493.88, .64], [440, 1.0],
    [698.46, .32], [698.46, .32], [659.25, .64], [523.25, .64], [587.33, .64], [523.25, 1.0]
  ];
  function playNext() {
    if (!playing || !audioContext) return;
    var item = melody[noteIndex % melody.length]; noteIndex++;
    var osc = audioContext.createOscillator(), gain = audioContext.createGain();
    osc.type = 'sine'; osc.frequency.value = item[0];
    gain.gain.setValueAtTime(0.0001, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.12, audioContext.currentTime + 0.025);
    gain.gain.exponentialRampToValueAtTime(0.0001, audioContext.currentTime + item[1] * 0.9);
    osc.connect(gain); gain.connect(audioContext.destination); osc.start(); osc.stop(audioContext.currentTime + item[1]);
    timer = setTimeout(playNext, item[1] * 1000);
  }
  function startMusic() {
    var AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) { button.textContent = 'Music not supported'; return; }
    if (!audioContext) audioContext = new AudioCtx();
    if (audioContext.state === 'suspended') audioContext.resume();
    playing = true; button.textContent = '♫ Music On'; playNext();
  }
  function stopMusic() { playing = false; clearTimeout(timer); button.textContent = '♫ Play Birthday Music'; }
  button.addEventListener('click', function () { if (playing) stopMusic(); else startMusic(); });
  // Try to start when the Happy Birthday scene appears; if blocked, the button remains available.
  setTimeout(function () { try { startMusic(); } catch (e) { button.textContent = '♫ Play Birthday Music'; } }, 10000);
})();



// Reliable direct navigation handler for the Cake button (also works if other animation code changes).
window.showCakePage = function(event) {
  if (event) { event.preventDefault(); event.stopPropagation(); }
  var page = document.getElementById('cake-page');
  if (!page) { alert('Cake page could not be found. Please check that the project files are all extracted together.'); return; }
  page.style.display = 'flex';
  page.style.visibility = 'visible';
  page.style.opacity = '1';
  page.classList.add('cake-page-show');
  page.setAttribute('aria-hidden', 'false');
  page.scrollTop = 0;
  document.body.style.overflow = 'hidden';
  var cake = document.getElementById('birthday-cake');
  if (cake) { try { cake.focus({preventScroll:true}); } catch(e) { cake.focus(); } }
};

// Navigate from the Happy Birthday scene to the separate cake page.
(function () {
  var openCakeButton = document.getElementById('go-to-cake-page');
  var cakePage = document.getElementById('cake-page');
  if (!openCakeButton || !cakePage) return;
  openCakeButton.addEventListener('click', function (event) {
    event.preventDefault();
    cakePage.classList.add('cake-page-show');
    cakePage.setAttribute('aria-hidden', 'false');
    // Put keyboard focus inside the cake page for accessibility.
    var cake = document.getElementById('birthday-cake');
    if (cake) cake.focus({ preventScroll: true });
  });
})();

// Cake interaction: one candle click extinguishes all candles, then tap the cake to cut it.
(function () {
  var cake = document.getElementById('birthday-cake');
  var candles = Array.prototype.slice.call(document.querySelectorAll('.cake-candle'));
  var instruction = document.getElementById('cake-instruction');
  var message = document.getElementById('cake-wish-message');
  if (!cake || !candles.length || !instruction || !message) return;
  cake.classList.add('cake-locked');
  function blowOutCandle(event) {
    event.stopPropagation();
    if (cake.classList.contains('cake-cut')) return;
    // A single click blows out every candle together.
    candles.forEach(function (candle) {
      candle.classList.add('extinguished');
      candle.setAttribute('aria-label', 'Candle extinguished');
    });
    cake.classList.remove('cake-locked');
    instruction.textContent = 'All candles are out! Now tap the cake to cut it 🎂';
  }
  candles.forEach(function (candle) { candle.addEventListener('click', blowOutCandle); });
  function cutCake() {
    if (cake.classList.contains('cake-cut')) return;
    if (candles.some(function (c) { return !c.classList.contains('extinguished'); })) {
      instruction.textContent = 'Tap any one candle to blow out all the candles 🕯️';
      return;
    }
    cake.classList.add('cake-cut');
    instruction.textContent = 'Yay! The cake is cut! 🎉';
    message.textContent = '';
    var nextButton = document.createElement('button');
    nextButton.type = 'button';
    nextButton.id = 'birthday-next-page';
    nextButton.className = 'birthday-next-page';
    nextButton.setAttribute('aria-label', 'Open a special message for you');
    nextButton.textContent = 'A Special Message for You 💌';
    message.appendChild(nextButton);
    nextButton.addEventListener('click', function () {
      var page = document.getElementById('heart-message-page');
      if (!page) {
        page = document.createElement('section');
        page.id = 'heart-message-page';
        page.className = 'heart-message-page';
        page.innerHTML = '<div class="heart-message-card"><div class="heart-message-icon">💌</div><p class="heart-message-eyebrow">A MESSAGE FROM THE HEART</p><h1>Happy Birthday,❤️</h1><p class="heart-message-body">Today is all about you — your smile, your dreams, and all the beautiful moments waiting ahead. May your life always be filled with love, laughter, peace, and a thousand little reasons to smile. You deserve every bit of happiness. Happy Birthday! 💗</p></div>';
        document.body.appendChild(page);
      }
      var cakePage = document.getElementById('cake-page');
      if (cakePage) cakePage.classList.remove('cake-page-show');
      page.classList.add('heart-message-page-show');
      page.setAttribute('aria-label', 'A special message for you');
      document.body.style.overflow = 'auto';
    });
  }
  cake.addEventListener('click', cutCake);
  cake.addEventListener('keydown', function (event) {
    if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); cutCake(); }
  });
})();
